# 墒策：可信需水预测与灌溉决策

AI＋农业独立参赛原型。项目从当前空目录新建，不复用其他参赛团队作品。当前完成范围是本地原型、历史回测、情景仿真与参赛材料，尚未报名、缴费、上传或提交。

## 先看作品

- 双击 `启动墒策.command`，浏览器进入本地工作台。
- `materials/墒策_技术方案.pdf`：31页LaTeX报告，按官方附件2七章大纲重写，封面团队名称、编号留空。编辑源为`paper/main.tex`。
- `materials/墒策_答辩演示.pdf`：供报名系统提交的答辩PDF；PPTX为可编辑源文件。
- `materials/墒策_演示视频.mp4`：合成语音解说与实际原型录屏。
- `materials/墒策_佐证材料.pdf`：来源、实验和系统截图，不包含虚构的第三方证明。
- `materials/报名字段.md`：14字名称、226字简介及填写说明。

## 核心结果

三地2018—2025年ERA5公开数据共8766行。2018—2022年训练，2023年校准，2024—2025年测试2193行。完整模型 MAE 0.775680 mm/日，较昨日值基线降低7.6847%，名义90%区间测试覆盖率91.0625%。

目标ET₀为Open-Meteo基于气象数据计算的参考值，不是田间测量。ERA5有发布延迟，因此本次仅构成事后历史回测。灌溉模块使用明确的土壤、Kc及有效雨量假设；结果不能被描述为实测节水、增产或收入。

## 运行与复现

本机已建立 `.venv`。已有数据下，训练、界面和推理均可离线运行。

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m src.pipeline
.venv/bin/python -m pytest -q
.venv/bin/python app/server.py --port 8765
```

浏览器打开 `http://127.0.0.1:8765`。仅监听回环地址。下载原始数据可运行 `scripts/fetch_inputs.py`，已存在文件会复用；来源和哈希见 `inputs/provenance.json`。该脚本重新执行会重新记录核验时间，正式交付包保留本次首次运行的记录。

`requirements.lock.txt`保存本次环境的完整版本。重训耗时受机器影响，推理时间不应当作跨硬件性能保证。`joblib`模型只应加载可信项目文件。

技术方案编译：`python3 scripts/build_latex_report.py`，需要XeLaTeX、ctex、Fandol字体和latexmk。扩展诊断与图表由`scripts/report_analysis.py`从原有CSV生成，包括季节覆盖、失败样本与策略敏感性；6月和7月覆盖分别为78.33%和79.03%，不能用全年91.06%替代夏季可靠性。

佐证材料生成：`scripts/build_materials.py`使用macOS Arial Unicode字体，已禁止覆盖现有LaTeX报告。答辩源生成器`build_slides.mjs`依赖Codex提供的Artifact Tool及对应校验器，普通环境可直接编辑交付PPTX，无须该工具。录屏依赖Playwright、Chrome、ffmpeg和macOS `say`。

## 文件与证据

| 位置 | 内容 |
| --- | --- |
| `inputs/rules` | 官网规则、参考大纲、调整通知、数据授权网页 |
| `inputs/weather` | 三地未改写的API原始JSON |
| `src/pipeline.py` | 特征、训练、区间、基线、消融、跨地区和仿真 |
| `src/agro.py` | 水量核算、参数约束及独立公式核验 |
| `app` | 本地HTTP服务及研究图谱界面 |
| `models` | 已训练模型、特征列表和校准常量 |
| `results` | 逐日数据、预测、180组策略实验、验证记录 |
| `materials` | 可读材料和可编辑源文件 |
| `submission` | 本地候选包、哈希和检查清单 |

## 提交前仍需完成

官方2026年10月10日调整通知将AI＋农业报名及作品提交截止时间改为 **2026年10月30日20:00，北京时间**。依据：<https://www.aicomp.cn/notice/notice-3/5435.html>，本次于2026年10月13日核验。

团队名称和编号按用户要求留空。报名、身份、缴费和正式命名须由真实团队补全。评审材料不能出现学校名称、指导教师信息。官网网盘模板遇验证码，本次使用已下载的官方参考大纲，提交前仍须核对网盘详细格式。用户没有授权上传，本项目未生成外部分享链接或上传网盘。

数据来源Open-Meteo / ERA5，数据许可CC BY 4.0，详见 `THIRD_PARTY.md`。Codex参与工程和材料编制；真实团队应审读、复现并掌握内容。
