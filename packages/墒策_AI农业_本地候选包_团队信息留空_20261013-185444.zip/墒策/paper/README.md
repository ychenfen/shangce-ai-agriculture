# 技术方案 LaTeX 源码

当前版本：31页（含封面、摘要、目录和参考文献），10幅图、22张表、33个编号公式。正文为七章，团队名称与编号留空。

主文件是`main.tex`，正文在`chapters/`，数据图在`figures/`，生成表在`tables/`。需要带ctex、Fandol字体和latexmk的TeX Live或MacTeX，采用XeLaTeX。

从完整工程根目录编译并更新交付PDF：

```sh
python3 scripts/build_latex_report.py
```

也可在本目录直接编译：

```sh
latexmk -xelatex -interaction=nonstopmode -file-line-error -halt-on-error main.tex
```

截图使用相对路径`../results/screenshots/dashboard.png`，所以应保留源码包的目录结构。图表PDF和表格源码已经包含在包中，单独编译不需要再次运行Python分析。

若需从原始结果重绘图表，在完整工程根目录运行`.venv/bin/python scripts/report_analysis.py`。该脚本依赖工程CSV与macOS Arial Unicode字体；换平台可将字体路径改成当地安装的中文字体。分析属于既有测试集的描述性诊断，不重新训练模型或更改原始预测。

31页PDF是当前技术方案。原11页ReportLab文稿已归档，旧的`build_materials.py`现在只生成辅助图与佐证，不覆盖LaTeX报告。

编译后应检查所有页面，尤其是公式、长表接续、图例和参考文献。修改数据或文本后，原有页数和打包验证需要同步更新。
