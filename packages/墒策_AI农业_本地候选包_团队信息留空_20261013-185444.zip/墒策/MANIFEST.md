# 墒策 · 项目清单与交接

更新：2026年10月13日。当前编辑者：Codex。最高完成阶段：本地制作与验证。

## 目标与范围

独立制作AIC算法主题赛初赛AI＋农业作品《墒策：可信需水预测与灌溉决策》。用户指定团队名称、编号先空着；视觉采用田间研究图谱风格。没有报名、缴费、上传、发布或提交。

## 输入与官方依据

- 原始附件：`inputs/用户提供赛题截图.jpg`，由本次用户提供的临时附件复制，选题为AIC算法主题赛、初赛、AI＋农业。
- 官网赛道：<https://www.aicomp.cn/tracks/tracks-5/4912.html>。
- 最新截止：2026年10月30日20:00（北京时间）。依据：<https://www.aicomp.cn/notice/notice-3/5435.html>，本次核验时间2026年10月13日。
- 官网规则、技术方案大纲、延期通知的本地副本在`inputs/rules/`。网盘详细模板遇验证码，尚未核对。
- 三地原始Open-Meteo ERA5响应在`inputs/weather/`。请求、时间和SHA-256在`inputs/provenance.json`。未复用其他团队工程。

## 当前交付件

| 文件 | 内容及本次核验 |
| --- | --- |
| `materials/墒策_技术方案.pdf` | 31页LaTeX报告；含摘要、目录、七章正文和参考文献；小于10MB |
| `paper/main.tex` | 当前可编辑主文件；章节、10幅图和22张表随源码保留 |
| `materials/墒策_答辩演示.pptx` | 10页；原生图表与表格；编辑源 |
| `materials/墒策_答辩演示.pdf` | 10页；LibreOffice转换；文字可选取、字体嵌入 |
| `materials/墒策_演示视频.mp4` | 232秒；1600×1000；H.264/AAC；8,715,011字节 |
| `materials/墒策_佐证材料.pdf` | 3页；来源、实验和真实原型截图 |
| `materials/报名字段.md` | 14字作品名、226字简介；团队信息留空 |
| `materials/演示视频脚本.md` | 实际录屏分镜、解说及合成语音披露 |
| `启动墒策.command` | macOS启动器；启动本地服务或打开已有服务 |

## 代码、结果与复现

核心方法在`src/pipeline.py`与`src/agro.py`，交互服务在`app/`。`models/shangce.joblib`为本次已训练模型。`results/summary.json`是页面与材料共同数据源，逐日预测与180组仿真分别在`predictions.csv`、`simulation_daily.csv`、`simulation_scenarios.csv`。

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m src.pipeline
.venv/bin/python -m pytest -q
.venv/bin/python app/server.py --port 8765
```

浏览器：<http://127.0.0.1:8765>。原始数据随包保留，安装依赖后训练与推理可离线。`requirements.lock.txt`记录本次环境。

技术报告：`python3 scripts/build_latex_report.py`。扩展分析与图表：`.venv/bin/python scripts/report_analysis.py`。正文采用XeLaTeX、ctex与Fandol，10幅图、22张表、33个编号公式。原11页文稿归档于`archives/report-v1-20261013/`，旧Markdown仅作为历史版本保留。

答辩：`scripts/build_slides.mjs`使用Codex Artifact Tool和其校验器，PDF转换需要LibreOffice；普通环境可直接编辑PPTX。生成器中的本机工具路径仅为构建依赖，不是网页运行依赖。浏览器检查使用`scripts/browser_check.cjs`，需安装Playwright和Google Chrome。

视频再生成：运行服务后，依次运行`scripts/prepare_video.py`、`node scripts/record_demo.cjs`、`scripts/render_video.py`。需要macOS Tingting语音、Playwright、Chrome与ffmpeg；本次视频已随包交付。

## 验证证据

- 核心测试：`python -m pytest -q`，9项通过，包含目标日/未来扰动防泄漏、土壤水量、供水上限、异常输入与区间分位数。
- 浏览器：`results/browser_checks.json`，9项通过。含真实模型推理、供水限制、决策下载、错误恢复和手机无横向溢出。
- 数据与文件：`scripts/verify_delivery.py`，65项通过，记录在`results/delivery_checks.json`。从CSV重算MAE、RMSE、R²、覆盖率，逐日水量汇总与180组结果一致，原始输入哈希匹配。
- 幻灯片：`results/slides_validation.json`记录10页PPTX结构、原生图表/表格与字体检查。哈希对应当前PPTX，记录中的v2文件名是归一命名前的构建名称。
- 视觉：31页LaTeX报告已全部渲染为页面图并目视检查总览，重点放大检查公式、覆盖热图和长表；编译无溢出、未定义引用或LaTeX警告，所有字体嵌入。当前预览在`.build/latex/final-review/`。答辩及佐证维持上次已核验版本。
- 视频：完整解码通过；在8、36、68、94、122、150、184、213、231秒抽帧检查，界面与章节对应，无空白尾帧。
- 校验器只能证明其检查范围，不代表田间有效性、获奖或赛事系统接受。
- LaTeX独立复现：`submission/墒策_31页技术方案_LaTeX源码_20261013.zip`解压到独立目录后编译成功，31页逐页文本和渲染像素与交付PDF一致。分月统计与敏感性表另从CSV复算通过。证据在`results/latex_report_validation.json`。

## 结果与限制

2193条测试样本，MAE 0.775680 mm/日，比昨日值降低7.6847%；名义90%区间的经验覆盖率91.0625%。新增描述诊断揭示6月78.33%、7月79.03%的季节性覆盖不足；留出郑州时覆盖87.9617%。没有据此重新调参，新增结果见`results/report_*.csv`和`report_analysis.json`。ERA5数据有发布延迟，当前是历史回测；ET₀为平台计算值。土壤和作物参数是假设，仿真用水和风险日不能当成实测节水或增产。

## 打包、恢复与下一步

`submission/`存放本地候选ZIP、SHA-256清单和包装核验记录。包内包括输入、源码、模型、结果与全部材料，排除虚拟环境、缓存及构建中间件。独立恢复副本位置记录在`submission/package_validation.json`，归档须通过CRC、逐文件哈希及恢复副本相同哈希检查。

旧版答辩保存在`.build/previous/`，不交付给评审。正式重训或较大修改前，先另存当前候选包；不要覆盖唯一可用版本。

下一步准确操作：真实团队核对`materials/提交前检查.md`，补齐身份与编号、核对网盘详细模板并审读材料。外部上传和提交尚未执行。
