# 来源与使用说明

- Open-Meteo Historical Weather API，指定 `models=era5`，Asia/Shanghai逐日聚合。原始响应保留坐标、字段和单位；API请求与文件SHA-256见inputs/provenance.json。数据由ERA5再分析及Open-Meteo派生处理得到。
  - 文档：https://open-meteo.com/en/docs/historical-weather-api
  - 数据许可：https://open-meteo.com/en/licence ，API数据为CC BY 4.0。
  - API服务条款：https://open-meteo.com/en/terms ，本次为非商业研究原型。
  - 本项目新增特征、模型预测和仿真结果，均为对原始资料的处理，不应将其视为源机构发布的结论。
- FAO-56：Allen, Pereira, Raes, Smith (1998)，Crop evapotranspiration。https://www.fao.org/4/x0490e/x0490e00.htm 。采用方法引用和自行编写的代码，无复制整本书。
- Angelopoulos & Bates (2021)，A Gentle Introduction to Conformal Prediction and Distribution-Free Uncertainty Quantification，arXiv:2107.07511。https://arxiv.org/abs/2107.07511 。用于误差区间设计参考，时间序列交换性条件不作保证。
- NumPy、pandas、SciPy、scikit-learn、joblib：遵循各自开源许可；交付包列出依赖而不打包安装环境。scikit-learn版本1.7.2。
- UI为本项目编写的HTML/CSS/JavaScript；没有复制其他参赛作品、外部图片、地图瓦片或图标库。
- 答辩PPTX由Codex Artifact Tool生成；当前技术方案为XeLaTeX/ctex排版，正文采用TeX Live所附Fandol字体，统计图采用本机Arial Unicode字体；佐证PDF由ReportLab生成。字体随PDF嵌入子集，不单独打包字体文件。视频由实际浏览器操作录制，Tingting合成语音解说，无人物声音仿制。
- 代码、试验设计、说明文稿和排版使用Codex辅助。没有第三方合作、专利、软著、论文发表或用户反馈证明。

上述在线许可页面于2026年10月13日下载到inputs/rules供核验。比赛原创性、AI辅助披露等要求以组委会规定为准，参赛团队需审读并确认自身的真实贡献。
