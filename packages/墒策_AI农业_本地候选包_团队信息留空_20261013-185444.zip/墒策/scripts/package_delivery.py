"""Freeze a local candidate archive and verify an independent recovery copy."""
from pathlib import Path
from datetime import datetime
import hashlib
import io
import json
import shutil
import zipfile

import fitz

ROOT = Path(__file__).resolve().parents[1]
STAMP = datetime.now().strftime('%Y%m%d-%H%M%S')
SUBMISSION = ROOT/'submission'
SUBMISSION.mkdir(exist_ok=True)
ARCHIVE = SUBMISSION/f'墒策_AI农业_本地候选包_团队信息留空_{STAMP}.zip'
RECOVERY = Path.home()/'Documents/AIC_AI农业_蒙奇_交付备份'/STAMP


def sha(data):
    return hashlib.sha256(data).hexdigest()


files = []
for directory in ['app','src','scripts','tests','models','inputs','results','materials','paper']:
    files.extend(p for p in (ROOT/directory).rglob('*') if p.is_file()
                 and '__pycache__' not in p.parts and p.suffix not in ['.pyc','.log','.aux','.toc','.out','.fls','.xdv','.fdb_latexmk','.gz']
                 and not p.name.startswith('.'))
files.extend(ROOT/n for n in ['README.md','MANIFEST.md','THIRD_PARTY.md',
                            'requirements.txt','requirements.lock.txt','启动墒策.command'])
files = sorted(files)
checksums = ''.join(f'{sha(p.read_bytes())}  {p.relative_to(ROOT).as_posix()}\n' for p in files)
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files:
        z.write(p, '墒策/'+p.relative_to(ROOT).as_posix())
    z.writestr('墒策/SHA256SUMS.txt',checksums.encode())

with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    for p in files:
        name='墒策/'+p.relative_to(ROOT).as_posix()
        assert sha(z.read(name)) == sha(p.read_bytes())
        assert z.getinfo(name).flag_bits & 0x800, 'UTF-8 path flag missing'
    for name,pages in [('墒策_技术方案',31),('墒策_答辩演示',10),('墒策_佐证材料',3)]:
        assert len(fitz.open(stream=z.read(f'墒策/materials/{name}.pdf'),filetype='pdf')) == pages
    with zipfile.ZipFile(io.BytesIO(z.read('墒策/materials/墒策_答辩演示.pptx'))) as pptx:
        assert pptx.testzip() is None
    assert len(json.loads(z.read('墒策/inputs/weather/jinan.json'))['daily']['time']) == 2922

digest = sha(ARCHIVE.read_bytes())
(SUBMISSION/'SHA256SUMS.txt').write_text(f'{digest}  {ARCHIVE.name}\n')
RECOVERY.mkdir(parents=True,exist_ok=False)
for p in [ARCHIVE,SUBMISSION/'SHA256SUMS.txt',ROOT/'MANIFEST.md']:
    shutil.copy2(p,RECOVERY/p.name)
assert sha((RECOVERY/ARCHIVE.name).read_bytes()) == digest
with zipfile.ZipFile(RECOVERY/ARCHIVE.name) as z:
    assert z.testzip() is None
    assert len(fitz.open(stream=z.read('墒策/materials/墒策_技术方案.pdf'),filetype='pdf')) == 31

result = {'created_local':STAMP,'archive':str(ARCHIVE),'sha256':digest,
          'bytes':ARCHIVE.stat().st_size,'file_count':len(files)+1,
          'utf8_paths':True,'crc_passed':True,'per_file_hashes_passed':True,
          'recovery_directory':str(RECOVERY),'recovery_hash_matches':True,
          'representative_recovery_pdf_opened':True,'external_submission':False}
(SUBMISSION/'package_validation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
shutil.copy2(SUBMISSION/'package_validation.json',RECOVERY/'package_validation.json')
print(json.dumps(result,ensure_ascii=False,indent=2))
