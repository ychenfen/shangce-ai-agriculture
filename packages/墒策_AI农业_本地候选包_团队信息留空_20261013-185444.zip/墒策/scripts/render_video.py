"""Combine the real browser capture with disclosed synthetic narration."""
from pathlib import Path
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
build = ROOT / '.build/video'
record = json.loads((build / 'recording.json').read_text())
duration = float(record['duration'])
actual = float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries',
    'format=duration', '-of', 'csv=p=0', record['path']]))
if actual < duration - .2:
    raise ValueError('Recording shorter than the storyboard')
subprocess.run(['ffmpeg', '-y', '-ss', str(max(0, actual-duration)), '-i', record['path'],
    '-i', str(build/'narration.wav'), '-t', str(duration), '-c:v', 'libx264',
    '-preset', 'fast', '-crf', '21', '-pix_fmt', 'yuv420p', '-c:a', 'aac',
    '-b:a', '128k', '-movflags', '+faststart', str(ROOT/'materials/墒策_演示视频.mp4')], check=True)
