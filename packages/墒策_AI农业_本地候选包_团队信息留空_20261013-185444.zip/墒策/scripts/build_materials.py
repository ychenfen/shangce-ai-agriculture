"""Create the report from the same measured JSON/CSV used by the application."""
from pathlib import Path
import json,html
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,PageBreak,Table,TableStyle,Image
from reportlab.lib.enums import TA_CENTER

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'materials'
S=json.loads((ROOT/'results/summary.json').read_text()); M=S['metrics'];SIM=S['simulation']['central']
FONT='/System/Library/Fonts/Supplemental/Arial Unicode.ttf'
pdfmetrics.registerFont(TTFont('CN',FONT)); FP=FontProperties(fname=FONT)
GREEN='#24533e';GRAY='#647267'
styles={
 'body':ParagraphStyle('body',fontName='CN',fontSize=10.5,leading=18,spaceAfter=10,textColor=colors.HexColor('#2a3c30'),wordWrap='CJK'),
 'title':ParagraphStyle('title',fontName='CN',fontSize=25,leading=36,spaceAfter=22,textColor=colors.HexColor(GREEN),wordWrap='CJK'),
 'sub':ParagraphStyle('sub',fontName='CN',fontSize=14,leading=23,spaceAfter=12,spaceBefore=9,textColor=colors.HexColor(GREEN),wordWrap='CJK'),
 'small':ParagraphStyle('small',fontName='CN',fontSize=8,leading=12,spaceAfter=7,textColor=colors.HexColor(GRAY),wordWrap='CJK'),
 'cell':ParagraphStyle('cell',fontName='CN',fontSize=9,leading=14,wordWrap='CJK'),
}
def para(t,style='body'):return Paragraph(html.escape(str(t)).replace('\n','<br/>'),styles[style])
def tbl(rows,widths=None):
    t=Table([[para(c,'cell') for c in r] for r in rows],colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#e7ecdf')),('LINEBELOW',(0,0),(-1,-1),.4,colors.HexColor('#d5ddcf')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),8),('BOTTOMPADDING',(0,0),(-1,-1),8)]));return t
def footer(c,doc):
    c.setFont('CN',8);c.setFillColor(colors.HexColor(GRAY));c.drawString(48,27,'墒策 / AI＋农业 / 历史回测与情景仿真');c.drawRightString(547,27,str(doc.page))
def doc(path,story):SimpleDocTemplate(str(path),pagesize=(595.28,841.89),rightMargin=48,leftMargin=48,topMargin=44,bottomMargin=48,title=S['title'],author='参赛团队',pageCompression=1).build(story,onFirstPage=footer,onLaterPages=footer)
def fig(path,w=493,h=260):return Image(str(path),width=w,height=h,kind='proportional')

def figures():
    plt.rcParams.update({'font.family':FP.get_name(),'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':GREEN,'xtick.color':GRAY,'ytick.color':GRAY,'axes.edgecolor':'#bdcbb8','figure.facecolor':'white','axes.facecolor':'white','font.size':10})
    keys=['climatology','persistence','calendar_only','no_et_history','ai'];names=['月均值','昨日值','日期位置','去除 ET₀ 历史','墒策']
    f,a=plt.subplots(figsize=(9,4));a.bar(names,[M[k]['mae'] for k in keys],color=['#bdc8b5']*4+[GREEN]);a.set_ylabel('MAE / mm·日⁻¹',fontproperties=FP);a.set_ylim(0,1.2)
    for i,k in enumerate(keys):a.text(i,M[k]['mae']+.025,f"{M[k]['mae']:.3f}",ha='center')
    a.grid(axis='y',alpha=.15);f.tight_layout();f.savefig(ROOT/'results/mae.png',dpi=170);plt.close(f)
    d=pd.read_csv(ROOT/'results/predictions.csv');d=d[(d.site=='shijiazhuang')&d.date.between('2025-06-16','2025-07-15')].reset_index(drop=True)
    f,a=plt.subplots(figsize=(9,4));a.fill_between(range(len(d)),d.lower,d.upper,color='#dce8ce',label='90% 名义区间');a.plot(d.et0,color='#9a9f93',label='参考值');a.plot(d.ai,color=GREEN,label='模型预测');a.set_xticks([0,7,14,21,29],[d.date.iloc[i][5:] for i in [0,7,14,21,29]]);a.set_ylabel('ET₀ / mm·日⁻¹',fontproperties=FP);a.legend(prop=FP,frameon=False);f.tight_layout();f.savefig(ROOT/'results/replay.png',dpi=170);plt.close(f)

def report():
    chapters=[]
    def page(title,items):chapters.append((title,items))
    page('一、作品概述',[
      ('p','墒策：可信需水预测与灌溉决策。作品面向缺少完整自动化灌溉设施、但能够记录地块参数的农技人员和农业教学场景。使用公开气象历史构造次日参考蒸散预测，再将预测误差区间引入根区水量核算，给出可复核的用水建议。'),
      ('h','1.1 目标与交付范围'),('p','本项目完成三地公开数据回测、本地模型推理、参数可调的灌溉建议、决策记录导出，以及技术方案、答辩材料和演示视频。当前系统定位为离线方法验证与教学演示原型，尚未形成田间控制系统。'),
      ('h','1.2 已获得的证据'),('table',[['指标','结果','口径'],['测试样本',str(S['splits']['test']),'三地2024—2025年，按目标日计'],['平均绝对误差',f"{M['ai']['mae']:.3f} mm/日",'对Open-Meteo提供的参考ET₀'],['相对昨日值基线',f"MAE降低{S['mae_improvement_pct']:.2f}%",'同一批样本配对比较'],['区间经验覆盖率',f"{100*S['interval']['all']['coverage']:.2f}%",'名义水平90%，时间序列不保证未来覆盖']]),
      ('h','1.3 作品贡献'),('p','贡献在于将时间留出评估、误差区间与灌溉约束连接成可操作流程；不宣称发明梯度提升或共形预测算法。界面同时呈现点预测、区间和基线，保留土壤假设、供水限制及建议依据，避免单个预测数字被直接当作灌溉处方。')])
    page('二、需求分析',[
      ('h','2.1 场景与需求依据'),('p','FAO-56将参考蒸散、作物系数与土壤水分平衡用于分析作物需水和水分胁迫[1]。据此，本作品把“明日需水如何变化”“当前根区还有多少水”“供水能力是否足够”作为三个需要共同回答的问题。需求来源为文献研究与原型分析，未开展农户访谈，不虚构合作基地或用户反馈。'),
      ('table',[['使用情形','原型响应','验证方式'],['只有近期气象历史','训练次日ET₀预测，保留昨日值基线','独立年份MAE、RMSE、R²'],['无法确定明日耗水','显示名义90%区间与实际覆盖率','2023校准、2024—2025测试'],['供水量受限','限制毛灌溉量并提示能力不足','边界测试与交互演示'],['需要复核决策','导出日期、模型版本、输入及建议','浏览器下载检查'],['缺少传感器实测','将土壤参数显式标成假设','界面、报告和视频一致披露']]),
      ('h','2.2 可行性与推广条件'),('p','模型使用结构化日数据，CPU即可训练与推理。原型只在本机运行，无账号、云推理费用或设备控制接口。后续实际试点需要接入及时可用的气象预报或现场观测，校准土壤容水量、作物系数与灌溉效率，并由农艺人员审查建议。当前三地均在华北及相邻区域，不能代表全国不同气候带。')])
    page('三、AI 技术工具选择与运用',[
      ('h','3.1 数据与预测对象'),('p','从Open-Meteo历史天气API获取ERA5模式下三地2018—2025年逐日数据[2]。三地各2922日，共8766条原始记录，关键变量缺失数为0。输入包含平均/最高/最低气温、平均湿度、10米风速、降水、短波辐射和地表气压。目标为平台按FAO方法计算的参考蒸散ET₀，单位mm/日；它是再分析驱动的计算值，不是田间蒸渗仪观测。'),
      ('table',[['地区','请求坐标','返回网格坐标'],*[ [ {'shijiazhuang':'石家庄','zhengzhou':'郑州','jinan':'济南'}[x['site']],f"{x['requested_lat']}, {x['requested_lon']}",f"{x['returned_lat']}, {x['returned_lon']}" ] for x in S['data_audit']]]),
      ('h','3.2 特征与模型'),('p','以目标日t为一行：每个气象变量和ET₀均仅取t−1、t−2、t−3、t−7的滞后值，以及截至t−1的7日均值；增加年内日期的正弦、余弦和经纬度，共49个特征。历史前7日不足以形成窗口，按地区删除。原始变量中的目标日天气不进入模型。'),
      ('p','采用scikit-learn 1.7.2的HistGradientBoostingRegressor[3]。固定参数为180轮、学习率0.055、最多15叶节点、L2正则8、最小叶样本25、随机种子42，禁用内部随机早停。参数在首次测试前固定，未按2024—2025测试结果搜索调参。小样本结构化数据使该方案比训练大型深度网络更易复现，但尚未与现代数值天气预报比较。'),
      ('p','开发使用Python、NumPy、pandas、scikit-learn及浏览器原生HTML/CSS/JavaScript。Codex辅助了代码、材料和测试编写，运行系统不依赖大语言模型接口。具体实现见src/pipeline.py；src/agro.py中的独立FAO日尺度计算函数用于公式核验，主实验目标直接采用API提供的ET₀。')])
    page('四、项目实施：时间边界与不确定性',[
      ('table',[['阶段','日期范围','有效样本','用途'],['训练','2018—2022',str(S['splits']['train']),'拟合树模型和月均值基线'],['校准','2023',str(S['splits']['calibration']),'仅估计绝对误差分位数'],['测试','2024—2025',str(S['splits']['test']),'一次时间留出评价']]),
      ('h','4.1 区间校准'),('p',f"校准残差为rᵢ＝|yᵢ−ŷᵢ|，选择第ceil((n+1)×0.9)个有序残差，得到q＝{S['q90']:.4f} mm/日。区间下界为max(0,ŷ−q)，上界为ŷ+q。这是分割式共形预测的简单形式[4]，使用跨地区合并校准集。"),
      ('p','标准共形覆盖结论依赖交换性。气象时间序列具有季节性、自相关和分布漂移，因此本作品仅报告留出年份的经验覆盖率，不承诺任意地点、任意未来年份都有90%覆盖率。固定宽度区间也未表达季节差异，未来可探索分季节校准和滚动更新。'),
      ('h','4.2 防泄漏与真实上线的区别'),('p','测试将目标日及未来天气全部扰动，确认目标日输入特征不变；所有滚动特征先shift(1)再rolling。跨地区检验逐一排除目标地区的训练及校准数据。ERA5历史再分析具有发布延迟，且本次未保存当年逐日可获取版本，因此这属于事后历史回测，不是经过实时可用性验证的业务预报。'),
      ('h','4.3 可解释范围'),('p','可解释性集中在决策规则与输入来源：用户可以查看历史窗口、模型训练截止日、校准截止日、灌溉触发条件和容量限制。尚未提供树模型的特征归因或因果解释，不将特征相关性描述为农学因果关系。')])
    page('四、项目实施：灌溉决策与系统',[
      ('h','4.4 规则定义'),('p','设D为当前根区亏缺，TAW为土壤总可用水量，RAW＝0.5×TAW为简化触发阈值，η为灌溉效率，Kc为作物系数。点预测策略使用ET₀均值，保守策略使用区间上界。先计算无雨预计亏缺D*＝D＋Kc×ET₀；当D*>RAW时，毛灌溉需求为(D*−0.25×TAW)/η，实际建议取该值与日供水上限的较小值，否则建议为0。'),
      ('p','规则只决定补水量，不预测产量。仿真在决策之后才读取当天实况降雨，使用0.8×降雨作为有效雨量。日末亏缺为clip(D＋Kc×ET₀−0.8P−ηI,0,TAW)，低于0的部分记排水，高于TAW的部分记未满足需水。该水桶没有根系生长、地下水补给、土壤分层和胁迫反馈，所有数值只用于方案比较。'),
      ('h','4.5 本地交互系统'),('p','浏览器请求本机Python服务，服务加载已训练模型，按所选地区和目标日重新推理。交互控件支持历史回放、点预测/上界策略切换、土壤亏缺调整、灌溉效率和供水上限输入，并导出JSON决策记录。异常数值、超范围日期和非法参数会返回错误，界面不会保留可导出的失效处方。'),
      ('image',ROOT/'results/screenshots/dashboard.png'),('small','图1 运行中的本地原型。截图中所有日期均为历史回放，未连接农业设备。')])
    page('五、应用成效：预测与消融',[
      ('table',[['模型','MAE','RMSE','R²'],*[[{'climatology':'地区月均值','persistence':'昨日值基线','calendar_only':'仅日期和位置','no_et_history':'去除ET₀历史','ai':'墒策完整模型'}[k],f"{v['mae']:.4f}",f"{v['rmse']:.4f}",f"{v['r2']:.4f}"] for k,v in M.items()]]),
      ('image',ROOT/'results/mae.png'),('small','图2 三地2024—2025年2193条样本的MAE，单位mm/日。'),
      ('p',f"完整模型MAE比昨日值基线降低{S['mae_improvement_pct']:.2f}%。以日期聚合跨地区误差差值、按14日块重采样1000次，探索性95%区间为[{S['paired_mae_difference_ci95'][0]:.4f}, {S['paired_mae_difference_ci95'][1]:.4f}] mm/日（基线误差减模型误差）。该区间仅反映所用重采样方案，不能替代外部独立数据验证。"),
      ('p','去除ET₀历史特征后，整体MAE只增加约0.0044 mm/日，收益较小；济南单地区甚至由0.7382降至0.7358。因而不能宣称机理历史特征在所有地区都带来改善。较大的优势来自近期多变量天气相对于日期均值的增量信息。')])
    page('五、应用成效：泛化与区间',[
      ('table',[['被完全留出的地区','模型MAE','昨日值MAE','区间覆盖率'],*[[{'shijiazhuang':'石家庄','zhengzhou':'郑州','jinan':'济南'}[k],f"{v['mae']:.4f}",f"{v['persistence_mae']:.4f}",f"{v['coverage']*100:.2f}%"] for k,v in S['transfer'].items()]]),
      ('p','跨地区模型只使用另两个地区2018—2022年训练，并用另两个地区2023年校准。郑州留出时区间覆盖率低于90%，说明跨地区迁移需要重新校准，不能直接复用原区间并承诺覆盖。三个试验地点较近，结果仅支持有限区域迁移可行性。'),
      ('image',ROOT/'results/replay.png'),('small','图3 石家庄2025年6月16日至7月15日的历史回放。灰线是事后参考值。'),
      ('p',f"完整三地模型在测试集的区间覆盖率为{100*S['interval']['all']['coverage']:.2f}%，平均宽度为{S['interval']['all']['width']:.3f} mm/日。区间较宽，会影响保守策略的用水量，不能只报覆盖率而忽略实用性。模型文件约416 KiB；当前机器50次单样本调用的中位耗时约{S['inference_median_ms']:.2f} ms，不包含页面加载或网络时间。")])
    page('五、应用成效：策略比较与边界',[
      ('table',[['策略','季均灌溉mm','风险日','排水mm'],*[[{'calendar':'7日定额25mm','sensor':'仅墒情阈值','persistence':'昨日值预测','ai':'AI点预测','upper':'AI区间上界'}[k],f"{SIM[k]['irrigation_mm']:.2f}",f"{SIM[k]['stress_days']:.2f}",f"{SIM[k]['drainage_mm']:.2f}"] for k in ['calendar','sensor','persistence','ai','upper']]]),
      ('p','表中为TAW=120 mm、η=0.85的基准情景，三地两年共6个5—9月生长季取均值。风险日定义为日末亏缺超过RAW，不等于减产日。每7日定额策略是人为设定的对照，不能当作当地农户的真实习惯。'),
      ('p',f"相对昨日值策略，AI点预测的季均灌溉量仅少{SIM['persistence']['irrigation_mm']-SIM['ai']['irrigation_mm']:.2f} mm，风险日由{SIM['persistence']['stress_days']:.2f}降至{SIM['ai']['stress_days']:.2f}。保守策略用水{SIM['upper']['irrigation_mm']:.2f} mm，在基准情景中风险日为0，但用水量高于点预测。这是风险与用水的取舍，不能表述为全面优于其他策略。"),
      ('h','5.4 敏感性设计'),('p','共计算3地×2年×3种TAW（80/120/160 mm）×2种效率（0.70/0.85）×5种策略＝180组季节策略实验。全部逐日轨迹与汇总CSV均随工程交付。所有策略初始亏缺为TAW的35%，无未来降雨输入，使用相同气象序列和作物系数，便于逐场景复核。'),
      ('h','5.5 应用价值的证据等级'),('p','已经得到：计算可复现、预测较简单基线改善、交互建议可追溯。仍需验证：实际田间节水量、作物产量、土壤传感器误差、不同作物与气候区迁移、经济收益。没有实测证据前，不估算销售收入、农户增收或推广面积。')])
    page('六、总结与展望',[
      ('h','6.1 已完成的工作'),('p','从空目录建立了独立数据、模型、试验与交互工程。数据原始响应可追溯，训练、校准和测试年份分离，公开对照与负面结果，能够在本机重现关键指标。原型证明了“不确定性参与灌溉建议”的实现可行性，尚不证明田间应用成效。'),
      ('h','6.2 关键限制'),('p','参考ET₀为计算标签，误差是对该标签的拟合误差；ERA5约25 km网格无法表达地块微气候；原型未接入实时观测和降雨预报；固定Kc与水桶参数未做当地校准；仅三地八年，极端事件和跨气候区泛化仍不充分；共形区间在时序漂移下只有经验表现。'),
      ('h','6.3 可执行的下一步'),('table',[['阶段','工作','验收条件'],['提交前','团队审读、解释代码与补齐编号；核对网盘模板','匿名评审材料完整，标题/简介/文件命名合规'],['影子运行准备','选择试点地块，记录土壤与作物参数','参数有测量来源、气象输入有可用时间戳'],['人工复核试点','建议不控阀，记录人工决策和实际用水','比较耗水、风险、误差和农技反馈'],['外部验证','引入独立地区和下一季数据','报告失败样本、漂移和校准更新结果']]),
      ('h','6.4 团队与AI辅助声明'),('p','真实成员、团队编号及职责尚未提供。代码实现、实验设计与文稿制作由AI辅助完成，参赛团队应审查、复现、修订并掌握内容，按赛事要求如实说明工具使用。没有编造专利、软著、合作证明或用户评价。最终提交由真实参赛团队负责。')])
    page('七、附录：复现与引用',[
      ('h','7.1 复现路径'),('p','在项目根目录创建Python 3.12虚拟环境并安装requirements.txt。原始数据已随包保留，离线实验不需要网络。依次运行：\npython -m src.pipeline\npython -m pytest -q\npython app/server.py --port 8765\n浏览器打开 http://127.0.0.1:8765。'),
      ('p','inputs/provenance.json记录请求URL、下载时间及SHA-256。results/predictions.csv为逐日预测，simulation_daily.csv为水量轨迹，simulation_scenarios.csv为180组汇总，summary.json是页面和材料的共同数据源。models/shangce.joblib为已训练模型，仅加载可信本地文件。'),
      ('h','7.2 参考文献与授权'),
      ('p','[1] Allen R G, Pereira L S, Raes D, Smith M. Crop evapotranspiration: Guidelines for computing crop water requirements. FAO Irrigation and Drainage Paper 56, 1998. https://www.fao.org/4/x0490e/x0490e00.htm'),
      ('p','[2] Open-Meteo. Historical Weather API, ERA5 option. https://open-meteo.com/en/docs/historical-weather-api。数据采用CC BY 4.0，保留来源署名；本次为非商业参赛研究。基于ERA5再分析，经过平台聚合与ET₀派生计算。'),
      ('p','[3] scikit-learn. HistGradientBoostingRegressor, v1.7.2. https://scikit-learn.org/1.7/modules/generated/sklearn.ensemble.HistGradientBoostingRegressor.html。工具采用BSD许可；NumPy、pandas、joblib等按各自许可使用。'),
      ('p','[4] Angelopoulos A N, Bates S. A Gentle Introduction to Conformal Prediction and Distribution-Free Uncertainty Quantification. arXiv:2107.07511, 2021. https://arxiv.org/abs/2107.07511'),
      ('p','[5] AIC大赛组委会. 2026 AIC“AI+农业”赛题及竞赛规则、技术方案参考大纲、2026年10月10日赛程调整通知. https://www.aicomp.cn/tracks/tracks-5/4912.html。访问日期：2026年10月13日。')])
    story=[Spacer(1,45),para('2026 年第八届\n全球校园人工智能算法精英大赛','sub'),para('算法主题赛 · AI＋农业','sub'),Spacer(1,36),para('墒策','title'),para('可信需水预测与灌溉决策','title'),para('技术方案','sub'),Spacer(1,38),para('团队名称：________________\n团队编号：________________\n赛题名称：AI＋农业\n作品名称：'+S['title']+'\n日期：2026 年 10 月 13 日'),Spacer(1,25),para('版本：本地可复现原型 v1.0\n数据范围：2018—2025 年\n证据范围：历史回测与情景仿真','small'),PageBreak()]
    md=['# '+S['title'],'','团队名称：________________；团队编号：________________','']
    for idx,(title,items) in enumerate(chapters):
        story.append(para(title,'title'));md+=['## '+title,'']
        for kind,value in items:
            if kind in ['p','small','h']:
                story.append(para(value,{'p':'body','small':'small','h':'sub'}[kind]));md += [('### ' if kind=='h' else '')+value,'']
            elif kind=='table':
                story+=[tbl(value,[493/len(value[0])]*len(value[0])),Spacer(1,12)];md+=['| '+' | '.join(map(str,value[0]))+' |','|'+'---|'*len(value[0])]+['| '+' | '.join(map(str,r))+' |' for r in value[1:]]+['']
            else:
                story.append(fig(value,h=270 if 'dashboard' in str(value) else 210));md+=['!['+value.stem+'](../results/'+str(value.relative_to(ROOT/'results'))+')','']
        if idx<len(chapters)-1:story.append(PageBreak())
    doc(OUT/'墒策_技术方案.pdf',story);(OUT/'墒策_技术方案.md').write_text('\n'.join(md))
    return chapters

def evidence():
    story=[para('墒策 · 佐证材料','title'),para('本文件提供原始来源、运行结果和复现路径，属于自有实验记录。未取得第三方试点、专利、软著或用户评价，不将本记录冒充第三方认证。'),para('1. 数据来源与完整性','sub')]
    prov=json.loads((ROOT/'inputs/provenance.json').read_text())
    for x in prov:
        if 'weather/' in x['file']:story+=[para(x['file'],'sub'),para(x['url'],'small'),para('SHA-256: '+x['sha256'],'small')]
    story +=[para('原始三地各2922行，字段单位以JSON内daily_units为准。响应原文未改写，处理结果由src/pipeline.py生成。'),PageBreak(),para('2. 模型运行记录','title'),tbl([['项目','值'],['训练/校准/测试',f"{S['splits']['train']} / {S['splits']['calibration']} / {S['splits']['test']}"],['MAE',f"{M['ai']['mae']:.6f}"],['RMSE',f"{M['ai']['rmse']:.6f}"],['R²',f"{M['ai']['r2']:.6f}"],['名义90%区间覆盖率',f"{S['interval']['all']['coverage']*100:.4f}%"],['策略实验',str(S['simulation']['scenario_count'])+'组']], [235,258]),Spacer(1,20),para('核心检查覆盖未来数据扰动、规则触发边界、供水容量限制、异常数值拒绝、水量平衡及区间分位数。机器可读结果与逐日CSV随完整工程交付。'),para('引用与AI辅助说明','sub'),para('数据来源Open-Meteo / ERA5，按CC BY 4.0署名。算法采用scikit-learn梯度提升树及分割式误差区间校准。Codex辅助代码、测试和文稿，运行原型不调用LLM。报告的评价均为本地执行结果，不包含第三方检测结论。'),PageBreak(),para('3. 系统功能实录','title'),fig(ROOT/'results/screenshots/dashboard.png',h=585),para('历史回放页面：模型预测、区间、对照基线、参数输入及灌溉建议。','small')]
    doc(OUT/'墒策_佐证材料.pdf',story)

if __name__=='__main__':
    figures()
    if not (ROOT/'paper/main.tex').exists():
        report()
    else:
        print('Technical report now uses paper/main.tex; preserving the LaTeX PDF.')
    evidence()
    print('supporting material generated')
