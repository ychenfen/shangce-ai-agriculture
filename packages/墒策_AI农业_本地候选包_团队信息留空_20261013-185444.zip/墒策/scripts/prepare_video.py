"""Generate disclosed macOS synthetic narration and a timed demo storyboard."""
from pathlib import Path
import subprocess,json,math
ROOT=Path(__file__).resolve().parents[1];BUILD=ROOT/'.build/video';BUILD.mkdir(parents=True,exist_ok=True)
SCENES=[
('overview','墒策：可信需水预测与灌溉决策','这是墒策，一个面向农业用水判断的独立功能原型。我们把短期参考蒸散预测、预测误差区间和根区水量核算放在同一个界面中。当前展示使用公开历史气象数据和假设地块参数，属于历史回放，没有接入田间设备。'),
('curve','逐日查看预测、参考值与不确定性','当前回放石家庄二零二五年七月十五日。预测只使用目标日前的气象历史。深绿色曲线是模型预测，浅色区域是名义百分之九十的预测区间，灰线是事后参考值。沿曲线移动可以查看逐日数值，也可以切换到九十天窗口，观察更长时间的变化。'),
('soil','同一预测下，土壤亏缺决定是否补水','预测不是灌溉处方，还需要土壤状态。这里的根区水量图随输入同步变化。把当前亏缺降到二十毫米，系统建议暂缓灌溉。再把亏缺提高到七十毫米，预计亏缺超过阈值，系统计算需要补充的水量。图上的土壤参数都是情景输入，并非真实传感器读数。'),
('capacity','供水上限与可追溯决策记录','现在把日供水上限改成五毫米。系统限制建议量，并提示供水能力不足。用户需要复核，而不是无条件执行模型结果。每次建议都可以导出记录，保留日期、地区、模型训练截止日、输入参数和计算结果，便于检查当时为什么作出这个决定。'),
('evidence','训练、校准与测试按年份隔离','模型使用三地八年的公开气象记录。二零一八至二零二二年训练，二零二三年校准误差区间，二零二四至二零二五年独立测试。两千一百九十三条测试样本中，平均绝对误差约零点七七六毫米每天，比沿用昨日值降低百分之七点六八。'),
('transfer','完整报告跨地区表现与失败边界','完整模型的测试区间覆盖率约百分之九十一点零六，但这不是对未来的保证。跨地区检验会排除目标地区的训练和校准样本。郑州被留出时，覆盖率低于百分之九十，说明迁移到新地区需要重新校准。历史蒸散特征的额外收益也较小，不能夸大单一模块的作用。'),
('simulation','用水与缺水风险，共同评价','策略回测同时展示用水量和缺水风险。横轴是季节灌溉量，纵轴是风险日。区间上界策略在基准情景中减少了风险日，却比点预测略多用水。全部实验包含一百八十组土壤、效率、地区、年份与策略组合。这里的结果来自简化水桶仿真，不是实测节水或增产效果。'),
('closing','下一步：当地校准与人工复核试点','墒策目前完成了数据处理、模型训练、对照实验和本地交互流程。原始数据、模型和逐日结果都可复现。下一步需要及时气象输入、实测土壤参数、当地作物系数以及人工复核试点。我们把方法效果、仿真效果和田间成效分别报告。本视频采用合成语音解说和实际原型录屏。')]
def run(args):subprocess.run(args,check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
scenes=[]
for i,(key,title,script) in enumerate(SCENES):
    txt=BUILD/f'{i:02}.txt';txt.write_text(script);aiff=BUILD/f'{i:02}.aiff'
    run(['say','-v','Tingting','-r','160','-f',str(txt),'-o',str(aiff)])
    dur=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(aiff)]))
    # Natural narration, short pauses. Each scene is at least 24 seconds.
    scene_dur=max(24,math.ceil(dur+.8));wav=BUILD/f'{i:02}.wav'
    run(['ffmpeg','-y','-i',str(aiff),'-af','apad','-t',str(scene_dur),'-ar','48000','-ac','1',str(wav)])
    scenes.append(dict(key=key,title=title,script=script,duration=scene_dur,wav=str(wav)))
    print(key,dur,scene_dur,flush=True)
total=sum(s['duration'] for s in scenes)
if not 180<=total<=295:raise ValueError(f'Video duration needs review: {total}')
(BUILD/'scenes.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
(BUILD/'audio-list.txt').write_text('\n'.join("file '"+s['wav']+"'" for s in scenes))
run(['ffmpeg','-y','-f','concat','-safe','0','-i',str(BUILD/'audio-list.txt'),'-c:a','pcm_s16le',str(BUILD/'narration.wav')])
(ROOT/'materials/演示视频脚本.md').write_text('# 演示视频脚本\n\n合成语音：macOS Tingting；画面为本地功能原型录屏。\n\n'+'\n\n'.join(f"## {i+1}. {s['title']}（{s['duration']}秒）\n\n{s['script']}" for i,s in enumerate(scenes)))
print('TOTAL',total,flush=True)
