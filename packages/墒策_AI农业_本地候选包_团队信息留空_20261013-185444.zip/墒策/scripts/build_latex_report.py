"""Compile the saved LaTeX project and copy the successful PDF to materials."""
from pathlib import Path
from datetime import datetime
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[1]
compiler=shutil.which('latexmk')
if not compiler and Path('/Library/TeX/texbin/latexmk').exists():
    compiler='/Library/TeX/texbin/latexmk'
if not compiler:
    raise SystemExit('Install TeX Live / MacTeX with XeLaTeX, ctex and latexmk.')
build=ROOT/'.build/latex';build.mkdir(parents=True,exist_ok=True)
subprocess.run([compiler,'-xelatex','-interaction=nonstopmode','-file-line-error',
    '-halt-on-error','-outdir='+str(build),'main.tex'],cwd=ROOT/'paper',check=True)
pdf=build/'main.pdf'
destination=ROOT/'materials/墒策_技术方案.pdf'
if destination.exists() and destination.read_bytes()!=pdf.read_bytes():
    archive=ROOT/'archives'/('report-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
    archive.mkdir(parents=True)
    shutil.copy2(destination,archive/destination.name)
shutil.copy2(pdf,destination)
print('Compiled:',destination)
print('Inspect rendered pages after any source or figure change.')
